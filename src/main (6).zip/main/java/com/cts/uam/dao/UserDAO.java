package com.cts.uam.dao;

import java.time.LocalDateTime;
import java.util.Optional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cts.uam.enums.UserStatus;
import com.cts.uam.model.User;
import com.cts.util.HibernateUtil;

/**
 * Database access for the shared cts_users table.
 * Inward only needs login-related operations: lookup, failed-attempt
 * tracking, and successful-login recording.
 */
public class UserDAO {

    private static final Logger LOG = LoggerFactory.getLogger(UserDAO.class);

    private static final int AUTO_LOCK_MINUTES = 30;
    private static final int MAX_FAILED_ATTEMPTS = 5;

    /** Find a user by exact username. Empty if not found. */
    public Optional<User> findByUsername(String username) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createNativeQuery(
                    "SELECT * FROM cts_users WHERE username = :username", User.class)
                    .setParameter("username", username)
                    .uniqueResultOptional();
        }
    }

    /**
     * Add 1 to the failed-attempt counter. If it reaches the limit,
     * lock the account for 30 minutes.
     */
    public void incrementFailedAttempts(User user) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();

            User managed = session.get(User.class, user.getId());
            if (managed == null) {
                session.getTransaction().rollback();
                return;
            }

            managed.setFailedAttempts(managed.getFailedAttempts() + 1);
            if (managed.getFailedAttempts() >= MAX_FAILED_ATTEMPTS) {
                managed.setLockedUntil(LocalDateTime.now().plusMinutes(AUTO_LOCK_MINUTES));
                managed.setStatus(UserStatus.LOCKED);
                LOG.info("UserDAO: user '{}' locked after {} failed attempts",
                        managed.getUsername(), managed.getFailedAttempts());
            }

            session.merge(managed);
            session.getTransaction().commit();
        }
    }

    /** Reset attempts, clear lock, stamp last login on success. */
    public void recordSuccessfulLogin(User user) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();

            User managed = session.get(User.class, user.getId());
            if (managed == null) {
                session.getTransaction().rollback();
                return;
            }

            managed.setFailedAttempts(0);
            managed.setLockedUntil(null);
            managed.setLastLogin(LocalDateTime.now());
            if (managed.getStatus() == UserStatus.LOCKED) {
                managed.setStatus(UserStatus.ACTIVE);
            }

            session.merge(managed);
            session.getTransaction().commit();
        }
    }
    
    /** Update only the password hash for a user. */
    public void updatePasswordHash(long userId, String newPasswordHash) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();
            User user = session.get(User.class, userId);
            if (user == null) {
                session.getTransaction().rollback();
                return;
            }
            user.setPasswordHash(newPasswordHash);
            session.merge(user);
            session.getTransaction().commit();
        }
    }
}