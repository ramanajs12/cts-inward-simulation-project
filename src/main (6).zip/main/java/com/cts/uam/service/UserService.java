package com.cts.uam.service;

import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cts.uam.dao.UserDAO;
import com.cts.uam.enums.AuthResultReason;
import com.cts.uam.model.AuthResult;
import com.cts.uam.model.User;

/**
 * Login business logic for the inward project.
 * Coordinates the DAO and applies the security rules
 * (locked / inactive checks, BCrypt password verify, lockout).
 */
public class UserService {

    private static final Logger LOG = LoggerFactory.getLogger(UserService.class);
    private final UserDAO userDAO = new UserDAO();

    /**
     * Authenticate a username + plain password against cts_users.
     * Never throws for bad credentials — returns an AuthResult instead.
     */
    public AuthResult authenticate(String username, String password) {

        Optional<User> found = userDAO.findByUsername(username);
        if (found.isEmpty()) {
            return AuthResult.failure(AuthResultReason.USER_NOT_FOUND);
        }

        User user = found.get();

        if (user.isLocked()) {
            return AuthResult.failure(AuthResultReason.ACCOUNT_LOCKED);
        }
        if (!user.isActive()) {
            return AuthResult.failure(AuthResultReason.ACCOUNT_INACTIVE);
        }

        boolean passwordMatches = BCrypt.checkpw(password, user.getPasswordHash());
        if (!passwordMatches) {
            userDAO.incrementFailedAttempts(user);
            User refreshed = userDAO.findByUsername(username).orElse(user);
            return refreshed.isLocked()
                    ? AuthResult.failure(AuthResultReason.ACCOUNT_LOCKED)
                    : AuthResult.wrongPassword(refreshed);
        }

        userDAO.recordSuccessfulLogin(user);
        LOG.info("UserService: user '{}' authenticated successfully", username);
        return AuthResult.success(user);
    }

    /** Used by the security filter to re-check a user's live status. */
    public Optional<User> findByUsername(String username) {
        return userDAO.findByUsername(username);
    }
    
    /**
     * Change the logged-in user's own password.
     * Verifies the current password, enforces strength, then stores a new BCrypt hash.
     */
    public void changeOwnPassword(String username, String currentPassword, String newPassword) {
        User user = userDAO.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("User not found."));

        if (!org.mindrot.jbcrypt.BCrypt.checkpw(currentPassword, user.getPasswordHash())) {
            throw new IllegalArgumentException("Current password is incorrect.");
        }

        validatePasswordStrength(newPassword);

        String newHash = org.mindrot.jbcrypt.BCrypt.hashpw(newPassword, org.mindrot.jbcrypt.BCrypt.gensalt());
        userDAO.updatePasswordHash(user.getId(), newHash);
        LOG.info("UserService: user '{}' changed own password", username);
    }

    /** Password rule: 8+ chars, 1 uppercase, 1 digit, 1 special character. */
    private void validatePasswordStrength(String password) {
        if (password == null
                || !password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$")) {
            throw new IllegalArgumentException(
                    "Password must be 8+ chars with 1 uppercase, 1 digit, and 1 special character.");
        }
    }
}