package com.cts.composer;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.HtmlBasedComponent;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Div;
import org.zkoss.zul.Label;
import org.zkoss.zk.ui.util.Clients;

/**
 * CheckerSidebarComposer — TV1 Sidebar
 *
 * UPGRADED to match outward project sidebar:
 *   - Collapse toggle button (☰) to shrink/expand sidebar
 *   - Accordion expand/collapse for Inward Clearing section
 *   - Active state tracking when menu item is clicked
 *   - Page navigation via CheckerDashboardComposer (existing pattern unchanged)
 */
public class CheckerSidebarComposer extends SelectorComposer<Component> {

    private static final long serialVersionUID = 1L;

    // ── TOGGLE BUTTON ─────────────────────────────────────────────
    @Wire("#checkerSidebarToggle")
    private Div checkerSidebarToggle;

    // ── INWARD CLEARING accordion ──────────────────────────────────
    @Wire("#tv1InwardHeader")
    private Div tv1InwardHeader;

    @Wire("#tv1InwardMenu")
    private Div tv1InwardMenu;

    @Wire("#tv1InwardArrow")
    private Label tv1InwardArrow;

    // ── STATE ──────────────────────────────────────────────────────
    private boolean isCollapsed = false;

    // ══════════════════════════════════════════════════════════════
    // INIT
    // ══════════════════════════════════════════════════════════════

    @Override
    public void doAfterCompose(Component comp) throws Exception {
        super.doAfterCompose(comp);

        // Set arrow to closed state initially
        if (tv1InwardArrow != null) {
            tv1InwardArrow.setValue("▶");
        }

        // Wire accordion click for Inward Clearing section
        wireAccordion(tv1InwardHeader, tv1InwardMenu, tv1InwardArrow);
    }

    // ══════════════════════════════════════════════════════════════
    // COLLAPSE TOGGLE
    // ══════════════════════════════════════════════════════════════

    @Listen("onClick = #checkerSidebarToggle")
    public void onToggleSidebar() {
        if (isCollapsed) {
            expandSidebar();
        } else {
            collapseSidebar();
        }
    }

    private void collapseSidebar() {
        // Close all submenus before collapsing
        closeAllSubmenus(getSelf());

        Component root = getSelf();
        String current = getSclass(root);
        setSclass(root, (current + " collapsed").trim());

        updateSidebarWidth("70px");
        isCollapsed = true;
    }

    private void expandSidebar() {
        Component root = getSelf();
        String current = getSclass(root);
        setSclass(root, current.replace(" collapsed", "").trim());

        updateSidebarWidth("260px");
        isCollapsed = false;
    }

    private void closeAllSubmenus(Component parent) {
        for (Component child : parent.getChildren()) {
            String sclass = getSclass(child);

            if (sclass.contains("cts-submenu")) {
                ((HtmlBasedComponent) child).setVisible(false);
            }

            if (child instanceof Label lbl && sclass.contains("cts-arrow")) {
                lbl.setValue("▶");
            }

            closeAllSubmenus(child);
        }
    }

    private void updateSidebarWidth(String width) {
        Clients.evalJavaScript(
            "var sidebar = document.querySelector('.app-sidebar, .z-west-body');" +
            "if (sidebar) { sidebar.style.width='" + width + "'; }");
    }

    // ══════════════════════════════════════════════════════════════
    // ACCORDION
    // ══════════════════════════════════════════════════════════════

    private void wireAccordion(Div header, Div menu, Label arrow) {
        if (header == null || menu == null || arrow == null) return;

        header.addEventListener("onClick", event -> {
            // Expand sidebar first if collapsed
            if (isCollapsed) {
                expandSidebar();
            }

            boolean isOpen = menu.isVisible();
            menu.setVisible(!isOpen);
            arrow.setValue(isOpen ? "▶" : "▼");
        });
    }

    // ══════════════════════════════════════════════════════════════
    // NAVIGATION — existing pattern unchanged
    // ══════════════════════════════════════════════════════════════

    @Listen("onClick=.cts-menu-item")
    public void navigate(Event event) {
        Component target = event.getTarget();

        // Walk up to find the component that has pagePath attribute
        while (target != null && target.getAttribute("pagePath") == null) {
            target = target.getParent();
        }
        if (target == null) return;

        String pagePath = target.getAttribute("pagePath").toString();
        if (pagePath == null || pagePath.trim().isEmpty()) return;

        // Update active styling
        clearActiveState(getSelf());
        setSclass(target, (getSclass(target) + " active").trim());

        // Navigate via CheckerDashboardComposer
        CheckerDashboardComposer.getInstance().loadPage(pagePath);
    }

    // ══════════════════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════════════════

    private void clearActiveState(Component parent) {
        String sclass = getSclass(parent);
        if (sclass.contains("cts-menu-item")) {
            setSclass(parent, sclass.replace("active", "").trim());
        }
        for (Component child : parent.getChildren()) {
            clearActiveState(child);
        }
    }

    private String getSclass(Component comp) {
        return (comp instanceof HtmlBasedComponent hbc && hbc.getSclass() != null)
            ? hbc.getSclass() : "";
    }

    private void setSclass(Component comp, String sclass) {
        if (comp instanceof HtmlBasedComponent hbc) {
            hbc.setSclass(sclass);
        }
    }
}
